---
name: Bug report
about: Report inaccurate behavior or documentation
title: "[Bug]: "
labels: bug
assignees: ""
---

## What happened?

## Expected behavior

## Steps to reproduce

## Gemini environment
- Gemini Apps / other:
- Date checked:

## Evidence or links
Do not include passwords, API keys, tokens, or private data.
