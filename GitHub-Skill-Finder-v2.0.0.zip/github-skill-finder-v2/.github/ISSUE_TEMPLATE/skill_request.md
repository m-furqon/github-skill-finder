---
name: Skill discovery request
about: Suggest a category or capability to improve discovery
title: "[Skill request]: "
labels: enhancement
assignees: ""
---

## Skill category or task

## What should the Skill Finder discover or assess?

## Example public GitHub repositories (optional)

## Expected outcome
